"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { User, Shield, Users } from "lucide-react"
import Image from "next/image"

export function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { login } = useAuth()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    const success = await login(email, password)

    if (success) {
      toast({
        title: "Login realizado",
        description: "Bem-vindo ao sistema!",
      })
    } else {
      toast({
        title: "Erro no login",
        description: "Usuário ou senha incorretos",
        variant: "destructive",
      })
    }

    setIsLoading(false)
  }

  const handleQuickLogin = async (username: string) => {
    setIsLoading(true)
    const success = await login(username, username)

    if (success) {
      toast({
        title: "Acesso realizado",
        description: `Bem-vindo, ${username}!`,
      })
    }
    setIsLoading(false)
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="space-y-1">
        <div className="flex justify-center mb-4">
          <Image
            src="/images/logo-fazenda-paraiso.png"
            alt="Logo Fazenda Paraíso"
            width={120}
            height={144}
            className="object-contain"
          />
        </div>
        <CardTitle className="text-2xl font-bold text-center">Controle de Produção</CardTitle>
        <CardDescription className="text-center">Sistema de sangria e produção de borracha natural</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Usuário</Label>
            <Input
              id="email"
              type="text"
              placeholder="Digite seu nome"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Senha</Label>
            <Input
              id="password"
              type="password"
              placeholder="Digite sua senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Entrando..." : "Entrar"}
          </Button>
        </form>

        <div className="mt-6 space-y-4">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">Acesso Rápido</span>
            </div>
          </div>

          <div className="space-y-3">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <Shield className="h-4 w-4" />
                <span>Administração</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickLogin("admin")}
                  disabled={isLoading}
                  className="w-full"
                >
                  <User className="h-3 w-3 mr-1" />
                  Alisson
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickLogin("fiscal")}
                  disabled={isLoading}
                  className="w-full"
                >
                  <User className="h-3 w-3 mr-1" />
                  Casio
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <Users className="h-4 w-4" />
                <span>Seringueiros</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {["anderson", "valdeci", "aquiles", "patrick", "michael", "messias", "zuzueli"].map((name) => (
                  <Button
                    key={name}
                    variant="outline"
                    size="sm"
                    onClick={() => handleQuickLogin(name)}
                    disabled={isLoading}
                    className="w-full capitalize"
                  >
                    {name}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
