"use client"

import { useState, useEffect } from "react"
import { getPerformanceRatings, savePerformanceRating, deletePerformanceRating } from "@/lib/storage"
import { getWorkerInventory } from "@/lib/tree-data"
import { WorkerPerformanceRating } from "@/lib/types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Trophy, Medal, Award, Plus, Pencil, Trash2, X } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export function PerformanceRanking() {
  const [ratings, setRatings] = useState<WorkerPerformanceRating[]>([])
  const [selectedMonth, setSelectedMonth] = useState<string>(() => {
    const now = new Date()
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
  })
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingRating, setEditingRating] = useState<WorkerPerformanceRating | null>(null)
  
  const [formData, setFormData] = useState({
    workerId: "",
    workerName: "",
    productionScore: 5,
    qualityScore: 5,
    disciplineScore: 5,
    notes: "",
  })

  useEffect(() => {
    loadRatings()

    const handleStorageChange = () => {
      loadRatings()
    }

    const handleCustomStorageUpdate = () => {
      loadRatings()
    }

    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("localStorageUpdate", handleCustomStorageUpdate)

    const intervalId = setInterval(() => {
      loadRatings()
    }, 2000)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("localStorageUpdate", handleCustomStorageUpdate)
      clearInterval(intervalId)
    }
  }, [])

  const loadRatings = () => {
    const allRatings = getPerformanceRatings()
    setRatings(allRatings)
  }

  const monthRatings = ratings
    .filter(r => r.month === selectedMonth)
    .sort((a, b) => b.overallScore - a.overallScore)

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-500" />
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />
      case 3:
        return <Medal className="h-6 w-6 text-amber-600" />
      default:
        return <Award className="h-6 w-6 text-muted-foreground" />
    }
  }

  const getRankBadge = (rank: number) => {
    switch (rank) {
      case 1:
        return (
          <Badge className="bg-yellow-500 text-white hover:bg-yellow-600">
            <Trophy className="h-3 w-3 mr-1" />
            1º Lugar
          </Badge>
        )
      case 2:
        return (
          <Badge className="bg-gray-400 text-white hover:bg-gray-500">
            <Medal className="h-3 w-3 mr-1" />
            2º Lugar
          </Badge>
        )
      case 3:
        return (
          <Badge className="bg-amber-600 text-white hover:bg-amber-700">
            <Medal className="h-3 w-3 mr-1" />
            3º Lugar
          </Badge>
        )
      default:
        return <Badge variant="outline">{rank}º Lugar</Badge>
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-green-600"
    if (score >= 6) return "text-blue-600"
    if (score >= 4) return "text-yellow-600"
    return "text-red-600"
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  const openDialog = (rating?: WorkerPerformanceRating) => {
    if (rating) {
      setEditingRating(rating)
      setFormData({
        workerId: rating.workerId,
        workerName: rating.workerName,
        productionScore: rating.productionScore,
        qualityScore: rating.qualityScore,
        disciplineScore: rating.disciplineScore,
        notes: rating.notes || "",
      })
    } else {
      setEditingRating(null)
      setFormData({
        workerId: "",
        workerName: "",
        productionScore: 5,
        qualityScore: 5,
        disciplineScore: 5,
        notes: "",
      })
    }
    setIsDialogOpen(true)
  }

  const handleSaveRating = () => {
    if (!formData.workerId || !formData.workerName) {
      alert("Selecione um seringueiro")
      return
    }

    const overallScore = (
      formData.productionScore * 0.4 +
      formData.qualityScore * 0.4 +
      formData.disciplineScore * 0.2
    )

    const newRating: WorkerPerformanceRating = {
      id: editingRating?.id || `rating-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      workerId: formData.workerId,
      workerName: formData.workerName,
      month: selectedMonth,
      productionScore: formData.productionScore,
      qualityScore: formData.qualityScore,
      disciplineScore: formData.disciplineScore,
      overallScore: overallScore,
      notes: formData.notes,
      ratedBy: "user",
      ratedByName: "Usuário",
      createdAt: editingRating?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    savePerformanceRating(newRating)
    setIsDialogOpen(false)
    loadRatings()
  }

  const handleDeleteRating = (id: string) => {
    if (confirm("Tem certeza que deseja excluir esta avaliação?")) {
      deletePerformanceRating(id)
      loadRatings()
    }
  }

  const workers = getWorkerInventory()

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="min-w-0">
          <h2 className="text-2xl sm:text-3xl font-bold break-words">Ranking de Desempenho</h2>
          <p className="text-sm sm:text-base text-muted-foreground break-words">Avaliação manual dos melhores seringueiros</p>
        </div>
        <Button onClick={() => openDialog()} className="gap-2 w-full sm:w-auto shrink-0">
          <Plus className="h-4 w-4" />
          <span className="truncate">Nova Avaliação</span>
        </Button>
      </div>

      <Card>
        <CardHeader className="p-4 sm:p-6">
          <CardTitle className="text-base sm:text-lg">Período de Avaliação</CardTitle>
        </CardHeader>
        <CardContent className="p-4 sm:p-6 pt-0">
          <Input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="max-w-full sm:max-w-xs"
          />
        </CardContent>
      </Card>

      {monthRatings.length >= 3 && (
        <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-3">
          <Card className="sm:order-1">
            <CardHeader className="text-center pb-2 sm:pb-3 p-4 sm:p-6">
              <div className="flex justify-center mb-1 sm:mb-2">
                <Medal className="h-10 w-10 sm:h-12 sm:w-12 text-gray-400" />
              </div>
              <CardTitle className="text-base sm:text-lg">2º Lugar</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-2 sm:space-y-3 p-4 sm:p-6 pt-0">
              <Avatar className="h-14 w-14 sm:h-16 sm:w-16 mx-auto">
                <AvatarFallback className="text-base sm:text-lg bg-secondary">
                  {getInitials(monthRatings[1].workerName)}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-semibold text-sm sm:text-base break-words">{monthRatings[1].workerName}</p>
                <p className={`text-xl sm:text-2xl font-bold ${getScoreColor(monthRatings[1].overallScore)}`}>
                  {monthRatings[1].overallScore.toFixed(1)}
                </p>
                <p className="text-xs text-muted-foreground">pontos</p>
              </div>
            </CardContent>
          </Card>

          <Card className="sm:order-2 border-primary shadow-lg">
            <CardHeader className="text-center pb-2 sm:pb-3 p-4 sm:p-6">
              <div className="flex justify-center mb-1 sm:mb-2">
                <Trophy className="h-12 w-12 sm:h-16 sm:w-16 text-yellow-500" />
              </div>
              <CardTitle className="text-lg sm:text-xl">1º Lugar</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-2 sm:space-y-3 p-4 sm:p-6 pt-0">
              <Avatar className="h-16 w-16 sm:h-20 sm:w-20 mx-auto">
                <AvatarFallback className="text-lg sm:text-xl bg-primary text-primary-foreground">
                  {getInitials(monthRatings[0].workerName)}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-bold text-base sm:text-lg break-words">{monthRatings[0].workerName}</p>
                <p className={`text-2xl sm:text-3xl font-bold ${getScoreColor(monthRatings[0].overallScore)}`}>
                  {monthRatings[0].overallScore.toFixed(1)}
                </p>
                <p className="text-xs sm:text-sm text-muted-foreground">pontos</p>
              </div>
            </CardContent>
          </Card>

          <Card className="sm:order-3">
            <CardHeader className="text-center pb-2 sm:pb-3 p-4 sm:p-6">
              <div className="flex justify-center mb-1 sm:mb-2">
                <Medal className="h-10 w-10 sm:h-12 sm:w-12 text-amber-600" />
              </div>
              <CardTitle className="text-base sm:text-lg">3º Lugar</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-2 sm:space-y-3 p-4 sm:p-6 pt-0">
              <Avatar className="h-14 w-14 sm:h-16 sm:w-16 mx-auto">
                <AvatarFallback className="text-base sm:text-lg bg-accent">{getInitials(monthRatings[2].workerName)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-semibold text-sm sm:text-base break-words">{monthRatings[2].workerName}</p>
                <p className={`text-xl sm:text-2xl font-bold ${getScoreColor(monthRatings[2].overallScore)}`}>
                  {monthRatings[2].overallScore.toFixed(1)}
                </p>
                <p className="text-xs text-muted-foreground">pontos</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Card>
        <CardHeader className="p-4 sm:p-6">
          <CardTitle className="text-base sm:text-lg">Ranking Completo</CardTitle>
          <CardDescription className="text-xs sm:text-sm break-words">
            Avaliação baseada em: Produção 40%, Qualidade 40% e Disciplina (frequência, recuperação) 20%
          </CardDescription>
        </CardHeader>
        <CardContent className="p-4 sm:p-6">
          {monthRatings.length === 0 ? (
            <div className="py-6 sm:py-8 text-center text-sm sm:text-base text-muted-foreground">
              Nenhuma avaliação registrada para este mês
            </div>
          ) : (
            <div className="space-y-2 sm:space-y-3">
              {monthRatings.map((rating, index) => (
                <div
                  key={rating.id}
                  className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4 p-3 sm:p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="w-10 sm:w-12 flex justify-center shrink-0">{getRankIcon(index + 1)}</div>
                    <Avatar className="shrink-0">
                      <AvatarFallback className="text-sm">{getInitials(rating.workerName)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm sm:text-base break-words truncate">{rating.workerName}</p>
                      <div className="flex gap-2 mt-1">{getRankBadge(index + 1)}</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between sm:justify-end gap-4">
                    <div className="text-left sm:text-right">
                      <p className={`text-xl sm:text-2xl font-bold ${getScoreColor(rating.overallScore)}`}>
                        {rating.overallScore.toFixed(1)}
                      </p>
                      <p className="text-xs text-muted-foreground">pontos</p>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-2 sm:gap-4 text-xs sm:text-sm shrink-0">
                      <div className="text-center">
                        <p className="font-semibold">{rating.productionScore}/10</p>
                        <p className="text-[10px] sm:text-xs text-muted-foreground hidden sm:block">Produção 40%</p>
                        <p className="text-[10px] sm:text-xs text-muted-foreground sm:hidden">Prod</p>
                      </div>
                      <div className="text-center">
                        <p className="font-semibold">{rating.qualityScore}/10</p>
                        <p className="text-[10px] sm:text-xs text-muted-foreground hidden sm:block">Qualidade 40%</p>
                        <p className="text-[10px] sm:text-xs text-muted-foreground sm:hidden">Qual</p>
                      </div>
                      <div className="text-center">
                        <p className="font-semibold">{rating.disciplineScore}/10</p>
                        <p className="text-[10px] sm:text-xs text-muted-foreground hidden sm:block">Disciplina 20%</p>
                        <p className="text-[10px] sm:text-xs text-muted-foreground sm:hidden">Disc</p>
                      </div>
                    </div>
                    
                    <div className="flex gap-1 sm:gap-2 shrink-0">
                      <Button size="icon" variant="ghost" className="h-8 w-8 sm:h-10 sm:w-10" onClick={() => openDialog(rating)}>
                        <Pencil className="h-3 w-3 sm:h-4 sm:w-4" />
                      </Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8 sm:h-10 sm:w-10" onClick={() => handleDeleteRating(rating.id)}>
                        <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingRating ? "Editar Avaliação" : "Nova Avaliação"}</DialogTitle>
            <DialogDescription>
              Avalie o desempenho do seringueiro em cada categoria (0-10)
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Seringueiro</Label>
              <Select
                value={formData.workerId}
                onValueChange={(value) => {
                  const worker = workers.find(w => w.id === value)
                  if (worker) {
                    setFormData({ ...formData, workerId: value, workerName: worker.workerName })
                  }
                }}
                disabled={!!editingRating}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um seringueiro" />
                </SelectTrigger>
                <SelectContent>
                  {workers.map((worker) => (
                    <SelectItem key={worker.id} value={worker.id}>
                      {worker.workerName} - Código {worker.code}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Produção (0-10)</Label>
                <Input
                  type="number"
                  min="0"
                  max="10"
                  step="0.5"
                  value={formData.productionScore}
                  onChange={(e) =>
                    setFormData({ ...formData, productionScore: parseFloat(e.target.value) || 0 })
                  }
                />
                <p className="text-xs text-muted-foreground">Peso 40%</p>
              </div>

              <div className="space-y-2">
                <Label>Qualidade (0-10)</Label>
                <Input
                  type="number"
                  min="0"
                  max="10"
                  step="0.5"
                  value={formData.qualityScore}
                  onChange={(e) =>
                    setFormData({ ...formData, qualityScore: parseFloat(e.target.value) || 0 })
                  }
                />
                <p className="text-xs text-muted-foreground">Peso 40%</p>
              </div>

              <div className="space-y-2">
                <Label>Disciplina (frequência, recuperação) (0-10)</Label>
                <Input
                  type="number"
                  min="0"
                  max="10"
                  step="0.5"
                  value={formData.disciplineScore}
                  onChange={(e) =>
                    setFormData({ ...formData, disciplineScore: parseFloat(e.target.value) || 0 })
                  }
                />
                <p className="text-xs text-muted-foreground">Peso 20%</p>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Observações (opcional)</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Adicione comentários sobre o desempenho..."
                rows={3}
              />
            </div>

            <div className="bg-muted p-4 rounded-lg">
              <p className="text-sm font-medium mb-2">Pontuação Final:</p>
              <p className="text-3xl font-bold">
                {(
                  formData.productionScore * 0.4 +
                  formData.qualityScore * 0.4 +
                  formData.disciplineScore * 0.2
                ).toFixed(1)}
                /10
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveRating}>
              {editingRating ? "Atualizar" : "Salvar"} Avaliação
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
