"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { getTasks, getInspections, addInspection, updateTask } from "@/lib/storage"
import type { Task, Inspection } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { ClipboardCheck, CheckCircle2, AlertTriangle, TrendingUp } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function TechnicalInspection() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [tasks, setTasks] = useState<Task[]>([])
  const [inspections, setInspections] = useState<Inspection[]>([])
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  // Inspection form state
  const [angle, setAngle] = useState([3])
  const [depth, setDepth] = useState([3])
  const [injuries, setInjuries] = useState([5])
  const [spoutCleanliness, setSpoutCleanliness] = useState([3])
  const [notes, setNotes] = useState("")

  useEffect(() => {
    loadData()
  }, [])

  const loadData = () => {
    const allTasks = getTasks().filter((t) => t.status === "completed")
    setTasks(allTasks)
    setInspections(getInspections())
  }

  const handleInspect = (task: Task) => {
    setSelectedTask(task)
    setAngle([3])
    setDepth([3])
    setInjuries([5])
    setSpoutCleanliness([3])
    setNotes("")
    setIsDialogOpen(true)
  }

  const handleSubmitInspection = () => {
    if (!user || !selectedTask) return

    const overallScore = (angle[0] + depth[0] + injuries[0] + spoutCleanliness[0]) / 4

    const newInspection: Inspection = {
      id: `insp-${Date.now()}`,
      taskId: selectedTask.id,
      inspectorId: user.id,
      inspectorName: user.name,
      date: new Date().toISOString().split("T")[0],
      angle: angle[0],
      depth: depth[0],
      injuries: injuries[0],
      spoutCleanliness: spoutCleanliness[0],
      overallScore,
      notes,
      createdAt: new Date().toISOString(),
    }

    addInspection(newInspection)
    updateTask(selectedTask.id, { status: "inspected", inspectionId: newInspection.id })
    loadData()
    setIsDialogOpen(false)
    toast({
      title: "Inspeção registrada",
      description: `Nota geral: ${overallScore.toFixed(1)}/5.0`,
    })
  }

  const getScoreColor = (score: number) => {
    if (score >= 4.5) return "text-primary"
    if (score >= 3.5) return "text-secondary"
    if (score >= 2.5) return "text-accent"
    return "text-destructive"
  }

  const getScoreBadge = (score: number) => {
    if (score >= 4.5)
      return (
        <Badge className="bg-primary text-primary-foreground">
          <CheckCircle2 className="h-3 w-3 mr-1" />
          Excelente
        </Badge>
      )
    if (score >= 3.5)
      return (
        <Badge className="bg-secondary text-secondary-foreground">
          <TrendingUp className="h-3 w-3 mr-1" />
          Bom
        </Badge>
      )
    if (score >= 2.5)
      return (
        <Badge className="bg-accent text-accent-foreground">
          <AlertTriangle className="h-3 w-3 mr-1" />
          Regular
        </Badge>
      )
    return (
      <Badge variant="destructive">
        <AlertTriangle className="h-3 w-3 mr-1" />
        Precisa Melhorar
      </Badge>
    )
  }

  const getAverageScore = () => {
    if (inspections.length === 0) return 0
    return inspections.reduce((sum, insp) => sum + insp.overallScore, 0) / inspections.length
  }

  const TaskCard = ({ task }: { task: Task }) => {
    const inspection = inspections.find((i) => i.taskId === task.id)

    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">
              Tarefa {task.taskType} - {task.workerName}
            </CardTitle>
            {inspection ? getScoreBadge(inspection.overallScore) : <Badge variant="outline">Aguardando Inspeção</Badge>}
          </div>
          <CardDescription>{new Date(task.date).toLocaleDateString("pt-BR")}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
            <span className="text-sm font-medium">Produção:</span>
            <span className="text-lg font-bold text-primary">{task.productionKg} kg</span>
          </div>

          {inspection ? (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Ângulo</p>
                  <p className="text-lg font-semibold">{inspection.angle}/5</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Profundidade</p>
                  <p className="text-lg font-semibold">{inspection.depth}/5</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Ferimentos</p>
                  <p className="text-lg font-semibold">{inspection.injuries}/5</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Limpeza</p>
                  <p className="text-lg font-semibold">{inspection.spoutCleanliness}/5</p>
                </div>
              </div>
              <div className="pt-3 border-t">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Nota Geral:</span>
                  <span className={`text-2xl font-bold ${getScoreColor(inspection.overallScore)}`}>
                    {inspection.overallScore.toFixed(1)}
                  </span>
                </div>
              </div>
              {inspection.notes && (
                <div className="pt-2">
                  <p className="text-xs text-muted-foreground mb-1">Observações:</p>
                  <p className="text-sm">{inspection.notes}</p>
                </div>
              )}
              <p className="text-xs text-muted-foreground">Fiscal: {inspection.inspectorName}</p>
            </div>
          ) : (
            <Button onClick={() => handleInspect(task)} className="w-full gap-2">
              <ClipboardCheck className="h-4 w-4" />
              Realizar Inspeção
            </Button>
          )}
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Fiscalização Técnica</h2>
          <p className="text-muted-foreground">Inspeção de qualidade da sangria</p>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Total de Inspeções</CardDescription>
            <CardTitle className="text-3xl text-primary">{inspections.length}</CardTitle>
          </CardHeader>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Nota Média Geral</CardDescription>
            <CardTitle className={`text-3xl ${getScoreColor(getAverageScore())}`}>
              {getAverageScore().toFixed(1)}/5.0
            </CardTitle>
          </CardHeader>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Aguardando Inspeção</CardDescription>
            <CardTitle className="text-3xl text-secondary">
              {tasks.filter((t) => !inspections.find((i) => i.taskId === t.id)).length}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Tasks List */}
      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="pending">Aguardando Inspeção</TabsTrigger>
          <TabsTrigger value="inspected">Inspecionadas</TabsTrigger>
        </TabsList>
        <TabsContent value="pending" className="space-y-4">
          {tasks.filter((t) => !inspections.find((i) => i.taskId === t.id)).length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                Nenhuma tarefa aguardando inspeção
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {tasks
                .filter((t) => !inspections.find((i) => i.taskId === t.id))
                .map((task) => (
                  <TaskCard key={task.id} task={task} />
                ))}
            </div>
          )}
        </TabsContent>
        <TabsContent value="inspected" className="space-y-4">
          {tasks.filter((t) => inspections.find((i) => i.taskId === t.id)).length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                Nenhuma tarefa inspecionada ainda
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {tasks
                .filter((t) => inspections.find((i) => i.taskId === t.id))
                .map((task) => (
                  <TaskCard key={task.id} task={task} />
                ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Inspection Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Inspeção Técnica</DialogTitle>
            <DialogDescription>Avalie os critérios de qualidade da sangria (1 = Ruim, 5 = Excelente)</DialogDescription>
          </DialogHeader>
          {selectedTask && (
            <div className="space-y-6 py-4">
              <div className="p-4 bg-muted rounded-lg">
                <p className="font-semibold">
                  Tarefa {selectedTask.taskType} - {selectedTask.workerName}
                </p>
                <p className="text-sm text-muted-foreground">
                  {new Date(selectedTask.date).toLocaleDateString("pt-BR")} - {selectedTask.productionKg}kg
                </p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Ângulo de Corte</Label>
                    <span className="text-lg font-bold text-primary">{angle[0]}/5</span>
                  </div>
                  <Slider value={angle} onValueChange={setAngle} min={1} max={5} step={1} />
                  <p className="text-xs text-muted-foreground">Avalie o ângulo correto do corte na casca</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Profundidade do Corte</Label>
                    <span className="text-lg font-bold text-primary">{depth[0]}/5</span>
                  </div>
                  <Slider value={depth} onValueChange={setDepth} min={1} max={5} step={1} />
                  <p className="text-xs text-muted-foreground">Profundidade adequada sem danificar o câmbio</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Ausência de Ferimentos</Label>
                    <span className="text-lg font-bold text-primary">{injuries[0]}/5</span>
                  </div>
                  <Slider value={injuries} onValueChange={setInjuries} min={1} max={5} step={1} />
                  <p className="text-xs text-muted-foreground">5 = sem ferimentos, 1 = muitos ferimentos</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Limpeza da Bica</Label>
                    <span className="text-lg font-bold text-primary">{spoutCleanliness[0]}/5</span>
                  </div>
                  <Slider value={spoutCleanliness} onValueChange={setSpoutCleanliness} min={1} max={5} step={1} />
                  <p className="text-xs text-muted-foreground">Estado de limpeza e manutenção da bica</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Observações</Label>
                  <Textarea
                    id="notes"
                    placeholder="Adicione observações sobre a inspeção..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={4}
                  />
                </div>

                <div className="p-4 bg-primary/10 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">Nota Geral Prevista:</span>
                    <span className="text-3xl font-bold text-primary">
                      {((angle[0] + depth[0] + injuries[0] + spoutCleanliness[0]) / 4).toFixed(1)}
                    </span>
                  </div>
                </div>
              </div>

              <Button onClick={handleSubmitInspection} className="w-full" size="lg">
                Registrar Inspeção
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
