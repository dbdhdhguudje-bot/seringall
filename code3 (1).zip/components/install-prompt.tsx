"use client"

export function InstallPrompt() {
  return null
}
