"use client"

import { useState } from "react"
import { ProductionRecording } from "@/components/production-recording"
import { PerformanceRanking } from "@/components/performance-ranking"
import { TreeInventory } from "@/components/tree-inventory"
import { StimulationCalendar } from "@/components/stimulation-calendar"
import { PestControl } from "@/components/pest-control"
import { AttendanceTracker } from "@/components/attendance-tracker"
import { BarChart3, Award, Home, Trees, Droplet, Bug, Menu, UserCheck } from "lucide-react"
import Image from "next/image"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"

type View = "home" | "attendance" | "production" | "ranking" | "trees" | "stimulation" | "pest-control"

export function DashboardLayout() {
  const [currentView, setCurrentView] = useState<View>("home")
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const renderView = () => {
    switch (currentView) {
      case "attendance":
        return <AttendanceTracker />
      case "production":
        return <ProductionRecording />
      case "ranking":
        return <PerformanceRanking />
      case "trees":
        return <TreeInventory />
      case "stimulation":
        return <StimulationCalendar />
      case "pest-control":
        return <PestControl />
      case "home":
      default:
        return <HomeView setView={setCurrentView} />
    }
  }

  const NavigationItems = ({ onItemClick }: { onItemClick?: () => void }) => (
    <>
      <Button
        variant={currentView === "home" ? "default" : "outline"}
        onClick={() => {
          setCurrentView("home")
          onItemClick?.()
        }}
        className="gap-2 w-full sm:w-auto justify-start text-base"
      >
        <Home className="h-5 w-5" />
        <span className="font-medium">Início</span>
      </Button>
      <Button
        variant={currentView === "attendance" ? "default" : "outline"}
        onClick={() => {
          setCurrentView("attendance")
          onItemClick?.()
        }}
        className="gap-2 w-full sm:w-auto justify-start text-base"
      >
        <UserCheck className="h-5 w-5" />
        <span className="font-medium">Presença</span>
      </Button>
      <Button
        variant={currentView === "production" ? "default" : "outline"}
        onClick={() => {
          setCurrentView("production")
          onItemClick?.()
        }}
        className="gap-2 w-full sm:w-auto justify-start text-base"
      >
        <BarChart3 className="h-5 w-5" />
        <span className="font-medium">Produção</span>
      </Button>
      <Button
        variant={currentView === "trees" ? "default" : "outline"}
        onClick={() => {
          setCurrentView("trees")
          onItemClick?.()
        }}
        className="gap-2 w-full sm:w-auto justify-start text-base"
      >
        <Trees className="h-5 w-5" />
        <span className="font-medium">Árvores</span>
      </Button>
      <Button
        variant={currentView === "stimulation" ? "default" : "outline"}
        onClick={() => {
          setCurrentView("stimulation")
          onItemClick?.()
        }}
        className="gap-2 w-full sm:w-auto justify-start text-base"
      >
        <Droplet className="h-5 w-5" />
        <span className="font-medium">Estimulação</span>
      </Button>
      <Button
        variant={currentView === "pest-control" ? "default" : "outline"}
        onClick={() => {
          setCurrentView("pest-control")
          onItemClick?.()
        }}
        className="gap-2 w-full sm:w-auto justify-start text-base"
      >
        <Bug className="h-5 w-5" />
        <span className="font-medium">Pragas</span>
      </Button>
      <Button
        variant={currentView === "ranking" ? "default" : "outline"}
        onClick={() => {
          setCurrentView("ranking")
          onItemClick?.()
        }}
        className="gap-2 w-full sm:w-auto justify-start text-base"
      >
        <Award className="h-5 w-5" />
        <span className="font-medium">Ranking</span>
      </Button>
    </>
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10 shadow-sm">
        <div className="container mx-auto px-4 sm:px-6 py-4 sm:py-5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 sm:gap-4 min-w-0 flex-1">
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-lg bg-background flex items-center justify-center overflow-hidden flex-shrink-0 shadow-sm">
              <Image
                src="/images/logo-fazenda-paraiso.png"
                alt="Fazenda Paraíso"
                width={56}
                height={56}
                className="object-cover"
              />
            </div>
            <div className="min-w-0 flex-1">
              <h1 className="text-lg sm:text-2xl font-bold truncate">Fazenda Paraíso</h1>
              <p className="text-sm sm:text-base text-muted-foreground truncate">Gestão do Seringal</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="outline" size="lg" className="h-12 w-12 bg-transparent">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80 p-6">
                <div className="mb-8">
                  <p className="font-semibold text-lg">Fazenda Paraíso</p>
                  <p className="text-base text-muted-foreground">Sistema de Gestão</p>
                </div>
                <nav className="flex flex-col gap-3">
                  <NavigationItems onItemClick={() => setMobileMenuOpen(false)} />
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 sm:px-6 py-5 sm:py-8">
        <nav className="hidden md:flex gap-3 mb-8 overflow-x-auto pb-2">
          <NavigationItems />
        </nav>

        <main>{renderView()}</main>
      </div>
    </div>
  )
}

function HomeView({ setView }: { setView: (view: View) => void }) {
  return (
    <div className="space-y-6 sm:space-y-8">
      <div>
        <h2 className="text-2xl sm:text-4xl font-bold mb-2">Bem-vindo!</h2>
        <p className="text-base sm:text-lg text-muted-foreground">Sistema de controle de sangria e produção</p>
      </div>

      <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
        <Button
          variant="outline"
          className="h-auto p-6 sm:p-8 flex flex-col items-start gap-4 sm:gap-5 hover:bg-primary/5 hover:border-primary bg-transparent"
          onClick={() => setView("attendance")}
        >
          <UserCheck className="h-10 w-10 sm:h-12 sm:w-12 text-primary" />
          <div className="text-left">
            <h3 className="font-bold text-lg sm:text-xl mb-1">Registro de Presença</h3>
            <p className="text-sm sm:text-base text-muted-foreground">Sangria, faltas e inspeções</p>
          </div>
        </Button>

        <Button
          variant="outline"
          className="h-auto p-6 sm:p-8 flex flex-col items-start gap-4 sm:gap-5 hover:bg-secondary/5 hover:border-secondary bg-transparent"
          onClick={() => setView("production")}
        >
          <BarChart3 className="h-10 w-10 sm:h-12 sm:w-12 text-secondary" />
          <div className="text-left">
            <h3 className="font-bold text-lg sm:text-xl mb-1">Produção</h3>
            <p className="text-sm sm:text-base text-muted-foreground">Registrar produção em kg</p>
          </div>
        </Button>

        <Button
          variant="outline"
          className="h-auto p-6 sm:p-8 flex flex-col items-start gap-4 sm:gap-5 hover:bg-chart-3/5 hover:border-chart-3 bg-transparent"
          onClick={() => setView("trees")}
        >
          <Trees className="h-10 w-10 sm:h-12 sm:w-12 text-chart-3" />
          <div className="text-left">
            <h3 className="font-bold text-lg sm:text-xl mb-1">Árvores</h3>
            <p className="text-sm sm:text-base text-muted-foreground">Inventário e contagem</p>
          </div>
        </Button>

        <Button
          variant="outline"
          className="h-auto p-6 sm:p-8 flex flex-col items-start gap-4 sm:gap-5 hover:bg-chart-4/5 hover:border-chart-4 bg-transparent"
          onClick={() => setView("stimulation")}
        >
          <Droplet className="h-10 w-10 sm:h-12 sm:w-12 text-chart-4" />
          <div className="text-left">
            <h3 className="font-bold text-lg sm:text-xl mb-1">Estimulação</h3>
            <p className="text-sm sm:text-base text-muted-foreground">Controle de aplicação de Ethrel</p>
          </div>
        </Button>

        <Button
          variant="outline"
          className="h-auto p-6 sm:p-8 flex flex-col items-start gap-4 sm:gap-5 hover:bg-destructive/5 hover:border-destructive bg-transparent"
          onClick={() => setView("pest-control")}
        >
          <Bug className="h-10 w-10 sm:h-12 sm:w-12 text-destructive" />
          <div className="text-left">
            <h3 className="font-bold text-lg sm:text-xl mb-1">Controle de Pragas</h3>
            <p className="text-sm sm:text-base text-muted-foreground">Fiscalização de pragas e doenças</p>
          </div>
        </Button>

        <Button
          variant="outline"
          className="h-auto p-6 sm:p-8 flex flex-col items-start gap-4 sm:gap-5 hover:bg-secondary/5 hover:border-secondary bg-transparent"
          onClick={() => setView("ranking")}
        >
          <Award className="h-10 w-10 sm:h-12 sm:w-12 text-secondary" />
          <div className="text-left">
            <h3 className="font-bold text-lg sm:text-xl mb-1">Ranking</h3>
            <p className="text-sm sm:text-base text-muted-foreground">Desempenho dos trabalhadores</p>
          </div>
        </Button>
      </div>
    </div>
  )
}
