"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Calendar, Plus, Droplet, Trash2, ChevronLeft, ChevronRight } from 'lucide-react'
import { getStimulationRecords, addStimulationRecord, deleteStimulationRecord } from "@/lib/storage"
import { TREE_INVENTORY_DATA } from "@/lib/tree-data"
import type { StimulationRecord } from "@/lib/types"

export function StimulationCalendar() {
  const { user } = useAuth()
  const [records, setRecords] = useState<StimulationRecord[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const [formData, setFormData] = useState({
    workerName: "",
    workerId: "",
    taskSection: "",
    applicationDate: new Date().toISOString().split("T")[0],
    notes: "",
  })

  useEffect(() => {
    loadRecords()
  }, [])

  const loadRecords = () => {
    const data = getStimulationRecords()
    setRecords(data)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const record: StimulationRecord = {
      id: `stim-${Date.now()}`,
      taskSection: formData.taskSection,
      workerName: formData.workerName,
      workerId: formData.workerId,
      applicationDate: formData.applicationDate,
      notes: formData.notes,
      registeredBy: user?.id || "",
      registeredByName: user?.name || "",
      createdAt: new Date().toISOString(),
    }

    addStimulationRecord(record)
    loadRecords()
    setIsDialogOpen(false)
    setFormData({
      workerName: "",
      workerId: "",
      taskSection: "",
      applicationDate: new Date().toISOString().split("T")[0],
      notes: "",
    })
  }

  const handleDelete = (recordId: string) => {
    if (confirm("Tem certeza que deseja excluir este registro?")) {
      deleteStimulationRecord(recordId)
      loadRecords()
    }
  }

  const handleWorkerChange = (workerId: string) => {
    const worker = TREE_INVENTORY_DATA.find((w) => w.id === workerId)
    if (worker) {
      setFormData({
        ...formData,
        workerId: worker.id,
        workerName: worker.workerName,
        taskSection: "",
      })
    }
  }

  const getAvailableSections = () => {
    if (!formData.workerId) return []
    const worker = TREE_INVENTORY_DATA.find((w) => w.id === formData.workerId)
    return worker?.sections.map((s) => s.section) || []
  }

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear()
    const month = date.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startingDayOfWeek = firstDay.getDay()

    return { daysInMonth, startingDayOfWeek, year, month }
  }

  const getRecordsForDate = (date: string) => {
    return records.filter((r) => r.applicationDate === date)
  }

  const previousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1))
  }

  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1))
  }

  const { daysInMonth, startingDayOfWeek, year, month } = getDaysInMonth(currentMonth)

  const monthNames = [
    "Janeiro",
    "Fevereiro",
    "Março",
    "Abril",
    "Maio",
    "Junho",
    "Julho",
    "Agosto",
    "Setembro",
    "Outubro",
    "Novembro",
    "Dezembro",
  ]

  const dayNames = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"]

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold flex items-center gap-2">
            <Droplet className="h-6 w-6 sm:h-8 sm:w-8 text-primary" />
            Controle de Estimulação com Ethrel
          </h2>
          <p className="text-sm sm:text-base text-muted-foreground">Registre a aplicação de Ethrel por trabalhador e tarefa</p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 w-full sm:w-auto">
              <Plus className="h-4 w-4" />
              Nova Aplicação
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Registrar Aplicação de Ethrel</DialogTitle>
              <DialogDescription>Selecione o trabalhador e a tarefa para registrar estimulação</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="worker" className="text-base">1. Trabalhador</Label>
                <Select value={formData.workerId} onValueChange={handleWorkerChange} required>
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="Selecione o trabalhador" />
                  </SelectTrigger>
                  <SelectContent>
                    {TREE_INVENTORY_DATA.map((worker) => (
                      <SelectItem key={worker.id} value={worker.id}>
                        {worker.workerName} ({worker.code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="section" className="text-base">2. Tarefa (E1, E2, E3, E4)</Label>
                <Select
                  value={formData.taskSection}
                  onValueChange={(value) => setFormData({ ...formData, taskSection: value })}
                  required
                  disabled={!formData.workerId}
                >
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="Selecione a tarefa/seção" />
                  </SelectTrigger>
                  <SelectContent>
                    {getAvailableSections().map((section) => (
                      <SelectItem key={section} value={section}>
                        {section}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {!formData.workerId && (
                  <p className="text-xs text-muted-foreground">Selecione um trabalhador primeiro</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="date" className="text-base">3. Data da Aplicação</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.applicationDate}
                  onChange={(e) => setFormData({ ...formData, applicationDate: e.target.value })}
                  required
                  className="h-12"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes" className="text-base">4. Observações (opcional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Adicione observações sobre a aplicação..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={3}
                  className="text-base"
                />
              </div>

              <Button type="submit" className="w-full h-12 text-base">
                Registrar Aplicação
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Calendar Navigation */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <Button variant="outline" size="icon" onClick={previousMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <CardTitle className="text-lg sm:text-xl">
              {monthNames[month]} {year}
            </CardTitle>
            <Button variant="outline" size="icon" onClick={nextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-1 sm:gap-2">
            {/* Day names */}
            {dayNames.map((day) => (
              <div key={day} className="text-center font-semibold text-xs sm:text-sm p-1 sm:p-2 text-muted-foreground">
                {day}
              </div>
            ))}

            {/* Empty cells for days before month starts */}
            {Array.from({ length: startingDayOfWeek }).map((_, i) => (
              <div key={`empty-${i}`} className="p-1 sm:p-2 min-h-20 sm:min-h-24 border border-transparent"></div>
            ))}

            {/* Calendar days */}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1
              const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
              const dayRecords = getRecordsForDate(dateStr)
              const isToday = dateStr === new Date().toISOString().split("T")[0]

              return (
                <div
                  key={day}
                  className={`p-1 sm:p-2 min-h-20 sm:min-h-24 border rounded-lg ${
                    isToday ? "border-primary bg-primary/5" : "border-border"
                  } ${dayRecords.length > 0 ? "bg-accent/10" : ""}`}
                >
                  <div className="font-semibold text-xs sm:text-sm mb-1">{day}</div>
                  <div className="space-y-1">
                    {dayRecords.map((record) => (
                      <div
                        key={record.id}
                        className="text-[10px] sm:text-xs bg-primary/20 rounded px-1 py-0.5 flex items-center justify-between gap-1"
                      >
                        <span className="font-medium truncate">{record.taskSection}</span>
                        <button
                          onClick={() => handleDelete(record.id)}
                          className="text-destructive hover:text-destructive/80"
                        >
                          <Trash2 className="h-2 w-2 sm:h-3 sm:w-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Records List */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg sm:text-xl">Histórico de Aplicações</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {records.length === 0 ? (
              <p className="text-center text-muted-foreground py-8 text-sm sm:text-base">Nenhuma aplicação registrada ainda.</p>
            ) : (
              records
                .sort((a, b) => new Date(b.applicationDate).getTime() - new Date(a.applicationDate).getTime())
                .map((record) => (
                  <div key={record.id} className="flex items-start justify-between border rounded-lg p-3 sm:p-4 gap-2">
                    <div className="space-y-1 flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="secondary" className="font-mono text-xs sm:text-sm">
                          {record.taskSection}
                        </Badge>
                        <span className="font-semibold text-sm sm:text-base truncate">{record.workerName}</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground">
                        <Calendar className="h-3 w-3 flex-shrink-0" />
                        <span>
                          {new Date(record.applicationDate + "T00:00:00").toLocaleDateString("pt-BR", {
                            day: "2-digit",
                            month: "long",
                            year: "numeric",
                          })}
                        </span>
                      </div>
                      {record.notes && <p className="text-xs sm:text-sm text-muted-foreground mt-2 break-words">{record.notes}</p>}
                      <p className="text-[10px] sm:text-xs text-muted-foreground mt-1">Registrado por: {record.registeredByName}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(record.id)}
                      className="text-destructive hover:text-destructive/80 flex-shrink-0"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
