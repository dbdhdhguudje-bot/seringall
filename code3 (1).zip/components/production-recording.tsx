"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { getMonthlyWeighings, addMonthlyWeighing, getUsers } from "@/lib/storage"
import type { MonthlyWeighing, User } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { Plus, TrendingUp, Calendar, Scale, Download, Share2, Trophy, Medal, Award } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts"

const COLORS = [
  "hsl(var(--primary))",
  "hsl(var(--secondary))",
  "hsl(var(--accent))",
  "#8b5cf6",
  "#f59e0b",
  "#10b981",
  "#ef4444",
  "#06b6d4",
]

export function ProductionRecording() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [weighings, setWeighings] = useState<MonthlyWeighing[]>([])
  const [workers, setWorkers] = useState<User[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [selectedWorkerId, setSelectedWorkerId] = useState("")
  const [selectedMonth, setSelectedMonth] = useState("")
  const [productionKg, setProductionKg] = useState("")
  const [filterMonth, setFilterMonth] = useState<string>("all")

  useEffect(() => {
    loadData()
    const handleStorageChange = () => {
      loadData()
    }

    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("dataUpdated", handleStorageChange)

    const interval = setInterval(loadData, 2000)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("dataUpdated", handleStorageChange)
      clearInterval(interval)
    }
  }, [user, filterMonth])

  const loadData = () => {
    const allWeighings = getMonthlyWeighings()
    const allWorkers = getUsers().filter((u) => u.role === "worker")

    setWorkers(allWorkers)

    let filtered = allWeighings

    // Se for trabalhador, mostrar apenas suas pesagens
    if (user?.role === "worker") {
      filtered = filtered.filter((w) => w.workerId === user.id)
    }

    // Filtrar por mês se selecionado
    if (filterMonth !== "all") {
      filtered = filtered.filter((w) => w.month === filterMonth)
    }

    setWeighings(filtered.sort((a, b) => b.month.localeCompare(a.month)))
  }

  const handleRegisterWeighing = () => {
    if (!selectedWorkerId || !selectedMonth || !productionKg) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos",
        variant: "destructive",
      })
      return
    }

    const kg = Number.parseFloat(productionKg)
    if (isNaN(kg) || kg <= 0) {
      toast({
        title: "Erro",
        description: "Informe uma produção válida em kg",
        variant: "destructive",
      })
      return
    }

    const worker = workers.find((w) => w.id === selectedWorkerId)
    if (!worker) return

    // Verificar se já existe pesagem para este trabalhador neste mês
    const existingWeighing = weighings.find((w) => w.workerId === selectedWorkerId && w.month === selectedMonth)

    if (existingWeighing) {
      toast({
        title: "Erro",
        description: "Já existe uma pesagem para este trabalhador neste mês",
        variant: "destructive",
      })
      return
    }

    const newWeighing: MonthlyWeighing = {
      id: `weighing-${Date.now()}`,
      workerId: worker.id,
      workerName: worker.name,
      month: selectedMonth,
      productionKg: kg,
      registeredBy: "user",
      registeredByName: "Usuário",
      createdAt: new Date().toISOString(),
    }

    addMonthlyWeighing(newWeighing)
    loadData()
    setIsDialogOpen(false)
    setSelectedWorkerId("")
    setSelectedMonth("")
    setProductionKg("")

    toast({
      title: "Pesagem registrada",
      description: `${kg}kg registrados para ${worker.name} em ${formatMonth(selectedMonth)}`,
    })
  }

  const formatMonth = (month: string) => {
    const [year, monthNum] = month.split("-")
    const monthNames = [
      "Janeiro",
      "Fevereiro",
      "Março",
      "Abril",
      "Maio",
      "Junho",
      "Julho",
      "Agosto",
      "Setembro",
      "Outubro",
      "Novembro",
      "Dezembro",
    ]
    return `${monthNames[Number.parseInt(monthNum) - 1]} ${year}`
  }

  const getTotalProduction = () => {
    return weighings.reduce((sum, w) => sum + w.productionKg, 0)
  }

  const getAverageProduction = () => {
    if (weighings.length === 0) return 0
    return weighings.reduce((sum, w) => sum + w.productionKg, 0) / weighings.length
  }

  const getUniqueMonths = () => {
    const months = new Set(weighings.map((w) => w.month))
    return Array.from(months).sort().reverse()
  }

  const getCurrentMonth = () => {
    const now = new Date()
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`
  }

  const getAvailableMonths = () => {
    const months = []
    const now = new Date()
    for (let i = 0; i < 12; i++) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const monthStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`
      months.push(monthStr)
    }
    return months
  }

  const getProductionRanking = () => {
    const workerProduction = new Map<string, { workerName: string; totalKg: number; weighingsCount: number }>()

    weighings.forEach((w) => {
      const existing = workerProduction.get(w.workerId) || { workerName: w.workerName, totalKg: 0, weighingsCount: 0 }
      existing.totalKg += w.productionKg
      existing.weighingsCount += 1
      workerProduction.set(w.workerId, existing)
    })

    return Array.from(workerProduction.values())
      .map((w) => ({ ...w, average: w.totalKg / w.weighingsCount }))
      .sort((a, b) => b.totalKg - a.totalKg)
  }

  const getMonthlyProductionData = () => {
    const monthlyData = new Map<string, number>()

    weighings.forEach((w) => {
      const existing = monthlyData.get(w.month) || 0
      monthlyData.set(w.month, existing + w.productionKg)
    })

    return Array.from(monthlyData.entries())
      .map(([month, total]) => ({ month: formatMonth(month), total }))
      .sort((a, b) => a.month.localeCompare(b.month))
      .slice(-6) // Últimos 6 meses
  }

  const getWorkerComparisonData = () => {
    return getProductionRanking()
      .slice(0, 10)
      .map((w) => ({
        name: w.workerName.split(" ")[0], // Primeiro nome
        total: w.totalKg,
        media: w.average,
      }))
  }

  const shareRankingWhatsApp = () => {
    const ranking = getProductionRanking()
    let message = `🏆 *RANKING DE PRODUÇÃO DE BORRACHA*\n📅 ${new Date().toLocaleDateString("pt-BR")}\n\n`

    ranking.forEach((worker, index) => {
      const medal = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `${index + 1}º`
      message += `${medal} *${worker.workerName}*\n`
      message += `   📊 Total: ${worker.totalKg.toFixed(1)} kg\n`
      message += `   📈 Média: ${worker.average.toFixed(1)} kg/mês\n`
      message += `   📋 Pesagens: ${worker.weighingsCount}\n\n`
    })

    message += `\n━━━━━━━━━━━━━━━━━━\n📊 Total Geral: ${getTotalProduction().toFixed(1)} kg\n👥 Seringueiros: ${ranking.length}`

    const blob = new Blob([message], { type: "text/plain;charset=utf-8" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `ranking-producao-${new Date().toISOString().split("T")[0]}.txt`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)

    toast({
      title: "Ranking salvo",
      description: "O arquivo foi baixado com sucesso",
    })
  }

  const downloadProductionReport = () => {
    const ranking = getProductionRanking()
    const monthlyData = getMonthlyProductionData()

    let report = `RELATÓRIO DE PRODUÇÃO DE BORRACHA\n`
    report += `Data: ${new Date().toLocaleDateString("pt-BR")}\n`
    report += `Período: ${filterMonth === "all" ? "Todos os meses" : formatMonth(filterMonth)}\n\n`
    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`

    report += `ESTATÍSTICAS GERAIS\n`
    report += `Total Produzido: ${getTotalProduction().toFixed(1)} kg\n`
    report += `Média Mensal: ${getAverageProduction().toFixed(1)} kg\n`
    report += `Pesagens Registradas: ${weighings.length}\n`
    report += `Mês Atual: ${weighings.filter((w) => w.month === getCurrentMonth()).length} pesagens\n\n`

    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`
    report += `RANKING DE SERINGUEIROS\n\n`

    ranking.forEach((worker, index) => {
      report += `${index + 1}º ${worker.workerName}\n`
      report += `   Total: ${worker.totalKg.toFixed(1)} kg\n`
      report += `   Média: ${worker.average.toFixed(1)} kg/mês\n`
      report += `   Pesagens: ${worker.weighingsCount}\n\n`
    })

    report += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`
    report += `PRODUÇÃO MENSAL\n\n`

    monthlyData.forEach((data) => {
      report += `${data.month}: ${data.total.toFixed(1)} kg\n`
    })

    report += `\n━━━━━━━━━━━━━━━━━━\n`
    report += `Sistema de Gerenciamento de Sangria\n`
    report += `Gerado automaticamente\n`

    const blob = new Blob([report], { type: "text/plain;charset=utf-8" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `relatorio-producao-${new Date().toISOString().split("T")[0]}.txt`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)

    toast({
      title: "Relatório baixado",
      description: "O relatório foi salvo com sucesso",
    })
  }

  const uniqueMonths = getUniqueMonths()
  const ranking = getProductionRanking()

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="min-w-0">
          <h2 className="text-2xl sm:text-3xl font-bold break-words">Registro de Produção</h2>
          <p className="text-sm sm:text-base text-muted-foreground break-words">Pesagem mensal de borracha natural</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <Select value={filterMonth} onValueChange={setFilterMonth}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Filtrar por mês" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os meses</SelectItem>
              {uniqueMonths.map((month) => (
                <SelectItem key={month} value={month}>
                  {formatMonth(month)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2 w-full sm:w-auto">
                <Plus className="h-4 w-4" />
                <span className="truncate">Registrar Pesagem</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Registrar Pesagem Mensal</DialogTitle>
                <DialogDescription>Registre a produção mensal de um trabalhador</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="worker">Trabalhador</Label>
                  <Select value={selectedWorkerId} onValueChange={setSelectedWorkerId}>
                    <SelectTrigger id="worker">
                      <SelectValue placeholder="Selecione o trabalhador" />
                    </SelectTrigger>
                    <SelectContent>
                      {workers.map((worker) => (
                        <SelectItem key={worker.id} value={worker.id}>
                          {worker.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="month">Mês</Label>
                  <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                    <SelectTrigger id="month">
                      <SelectValue placeholder="Selecione o mês" />
                    </SelectTrigger>
                    <SelectContent>
                      {getAvailableMonths().map((month) => (
                        <SelectItem key={month} value={month}>
                          {formatMonth(month)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="production">Produção (kg)</Label>
                  <Input
                    id="production"
                    type="number"
                    step="0.1"
                    placeholder="0.0"
                    value={productionKg}
                    onChange={(e) => setProductionKg(e.target.value)}
                  />
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Informe a produção total de borracha do mês
                  </p>
                </div>
              </div>
              <Button onClick={handleRegisterWeighing} className="w-full">
                Registrar Pesagem
              </Button>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="pb-2 sm:pb-3 p-4 sm:p-6">
            <CardDescription className="text-xs sm:text-sm">Total Produzido</CardDescription>
            <CardTitle className="text-2xl sm:text-3xl text-primary break-words">
              {getTotalProduction().toFixed(1)} kg
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 sm:p-6 pt-0">
            <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground">
              <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4 shrink-0" />
              <span className="break-words">{weighings.length} pesagens registradas</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2 sm:pb-3 p-4 sm:p-6">
            <CardDescription className="text-xs sm:text-sm">Média Mensal</CardDescription>
            <CardTitle className="text-2xl sm:text-3xl text-secondary break-words">
              {getAverageProduction().toFixed(1)} kg
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 sm:p-6 pt-0">
            <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground">
              <Calendar className="h-3 w-3 sm:h-4 sm:w-4 shrink-0" />
              <span className="break-words">Por trabalhador/mês</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2 sm:pb-3 p-4 sm:p-6">
            <CardDescription className="text-xs sm:text-sm">Mês Atual</CardDescription>
            <CardTitle className="text-2xl sm:text-3xl text-accent break-words">
              {weighings.filter((w) => w.month === getCurrentMonth()).length}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 sm:p-6 pt-0">
            <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground">
              <Scale className="h-3 w-3 sm:h-4 sm:w-4 shrink-0" />
              <span className="break-words">Pesagens em {formatMonth(getCurrentMonth())}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="p-4 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="min-w-0">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Trophy className="h-4 w-4 sm:h-5 sm:w-5 text-yellow-500 shrink-0" />
                <span className="break-words">Ranking de Produção</span>
              </CardTitle>
              <CardDescription className="text-xs sm:text-sm break-words">
                Seringueiros com maior produção total
              </CardDescription>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button
                variant="outline"
                size="sm"
                className="flex-1 sm:flex-initial text-xs sm:text-sm bg-transparent"
                onClick={shareRankingWhatsApp}
              >
                <Share2 className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2 shrink-0" />
                <span className="truncate">WhatsApp</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="flex-1 sm:flex-initial text-xs sm:text-sm bg-transparent"
                onClick={downloadProductionReport}
              >
                <Download className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2 shrink-0" />
                <span className="truncate">Baixar</span>
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-4 sm:p-6">
          {ranking.length === 0 ? (
            <div className="py-6 sm:py-8 text-center text-sm sm:text-base text-muted-foreground">
              Nenhum dado de produção disponível
            </div>
          ) : (
            <div className="space-y-2 sm:space-y-3">
              {ranking.map((worker, index) => (
                <div
                  key={index}
                  className={`flex items-center gap-3 sm:gap-4 p-3 sm:p-4 rounded-lg border transition-all ${
                    index < 3 ? "bg-gradient-to-r from-primary/5 to-transparent border-primary/20" : "hover:bg-muted/50"
                  }`}
                >
                  <div className="flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 shrink-0">
                    {index === 0 && <Trophy className="h-6 w-6 sm:h-8 sm:w-8 text-yellow-500" />}
                    {index === 1 && <Medal className="h-6 w-6 sm:h-8 sm:w-8 text-gray-400" />}
                    {index === 2 && <Award className="h-6 w-6 sm:h-8 sm:w-8 text-orange-600" />}
                    {index > 2 && (
                      <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-muted flex items-center justify-center font-bold text-xs sm:text-sm text-muted-foreground">
                        {index + 1}
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2">
                      <p className="font-semibold text-sm sm:text-base break-words truncate">{worker.workerName}</p>
                      {index < 3 && (
                        <Badge variant="secondary" className="text-xs w-fit">
                          {index === 0 ? "1º Lugar" : index === 1 ? "2º Lugar" : "3º Lugar"}
                        </Badge>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-2 sm:gap-4 text-xs sm:text-sm text-muted-foreground mt-1">
                      <span className="break-words">📊 {worker.weighingsCount} pesagens</span>
                      <span className="break-words">📈 Média: {worker.average.toFixed(1)} kg/mês</span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-lg sm:text-2xl font-bold text-primary break-words">
                      {worker.totalKg.toFixed(1)} kg
                    </p>
                    <p className="text-[10px] sm:text-xs text-muted-foreground">Total</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {weighings.length > 0 && (
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Produção Mensal</CardTitle>
              <CardDescription>Evolução da produção nos últimos meses</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={getMonthlyProductionData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" angle={-45} textAnchor="end" height={80} />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="total"
                    stroke="hsl(var(--primary))"
                    strokeWidth={2}
                    name="Produção (kg)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Comparação entre Seringueiros</CardTitle>
              <CardDescription>Top 10 produtores</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={getWorkerComparisonData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="total" fill="hsl(var(--primary))" name="Total (kg)" />
                  <Bar dataKey="media" fill="hsl(var(--secondary))" name="Média (kg)" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Weighings List */}
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Pesagens</CardTitle>
          <CardDescription>Registro mensal de produção de borracha</CardDescription>
        </CardHeader>
        <CardContent>
          {weighings.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">Nenhuma pesagem registrada</div>
          ) : (
            <div className="space-y-3">
              {weighings.map((weighing) => (
                <div
                  key={weighing.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-4 flex-1">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Scale className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{weighing.workerName}</p>
                        <Badge variant="outline">{formatMonth(weighing.month)}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Registrado por {weighing.registeredByName} em{" "}
                        {new Date(weighing.createdAt).toLocaleDateString("pt-BR")}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-primary">{weighing.productionKg} kg</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
