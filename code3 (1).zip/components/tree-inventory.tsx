"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { TREE_INVENTORY_DATA, ADDITIONAL_EXTRA_TREES, GRAND_TOTAL_TREES } from "@/lib/tree-data"
import { Trees, User } from "lucide-react"

export function TreeInventory() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Contagem de Árvores</h2>
        <p className="text-muted-foreground">Inventário completo das árvores por trabalhador e seção</p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Geral</CardTitle>
            <Trees className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{GRAND_TOTAL_TREES.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">árvores no total</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Trabalhadores</CardTitle>
            <User className="h-4 w-4 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{TREE_INVENTORY_DATA.length}</div>
            <p className="text-xs text-muted-foreground">trabalhadores ativos</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Árvores Extras</CardTitle>
            <Trees className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(
                TREE_INVENTORY_DATA.reduce((acc, w) => acc + (w.extraTrees || 0), 0) + ADDITIONAL_EXTRA_TREES
              ).toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">árvores extras</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Média por Trabalhador</CardTitle>
            <Trees className="h-4 w-4 text-chart-3" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.round(
                TREE_INVENTORY_DATA.reduce((acc, w) => acc + w.totalTrees + (w.extraTrees || 0), 0) /
                  TREE_INVENTORY_DATA.length,
              ).toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">árvores por trabalhador</p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Worker Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Detalhamento por Trabalhador</CardTitle>
          <CardDescription>Seções e contagem de árvores atribuídas a cada trabalhador</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {TREE_INVENTORY_DATA.map((worker) => (
              <div key={worker.id} className="border rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className="text-lg font-bold px-3 py-1">
                      {worker.code}
                    </Badge>
                    <h3 className="text-xl font-semibold capitalize">{worker.workerName}</h3>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-primary">
                      {(worker.totalTrees + (worker.extraTrees || 0)).toLocaleString()}
                    </div>
                    <div className="text-sm text-muted-foreground">árvores totais</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {worker.sections.map((section) => (
                    <div key={section.section} className="bg-muted/50 rounded-md p-3 text-center">
                      <div className="text-sm font-medium text-muted-foreground">{section.section}</div>
                      <div className="text-lg font-bold">{section.treeCount.toLocaleString()}</div>
                    </div>
                  ))}
                </div>

                {worker.extraTrees && (
                  <div className="flex items-center gap-2 text-sm">
                    <Badge variant="secondary">Extra</Badge>
                    <span className="font-medium">{worker.extraTrees} árvores extras</span>
                  </div>
                )}
              </div>
            ))}

            {/* Additional Extra Trees */}
            <div className="border rounded-lg p-4 bg-accent/5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className="text-lg font-bold px-3 py-1">
                    01
                  </Badge>
                  <h3 className="text-xl font-semibold">Extra Adicional</h3>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-accent">{ADDITIONAL_EXTRA_TREES.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">árvores extras</div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Table */}
      <Card>
        <CardHeader>
          <CardTitle>Resumo da Contagem</CardTitle>
          <CardDescription>Visão geral consolidada</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Código</TableHead>
                <TableHead>Trabalhador</TableHead>
                <TableHead className="text-right">Seções</TableHead>
                <TableHead className="text-right">Total Base</TableHead>
                <TableHead className="text-right">Extras</TableHead>
                <TableHead className="text-right">Total Final</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {TREE_INVENTORY_DATA.map((worker) => (
                <TableRow key={worker.id}>
                  <TableCell>
                    <Badge variant="outline">{worker.code}</Badge>
                  </TableCell>
                  <TableCell className="font-medium capitalize">{worker.workerName}</TableCell>
                  <TableCell className="text-right">{worker.sections.length}</TableCell>
                  <TableCell className="text-right">{worker.totalTrees.toLocaleString()}</TableCell>
                  <TableCell className="text-right">{worker.extraTrees?.toLocaleString() || "-"}</TableCell>
                  <TableCell className="text-right font-bold">
                    {(worker.totalTrees + (worker.extraTrees || 0)).toLocaleString()}
                  </TableCell>
                </TableRow>
              ))}
              <TableRow>
                <TableCell>
                  <Badge variant="outline">01</Badge>
                </TableCell>
                <TableCell className="font-medium">Extra Adicional</TableCell>
                <TableCell className="text-right">-</TableCell>
                <TableCell className="text-right">-</TableCell>
                <TableCell className="text-right">{ADDITIONAL_EXTRA_TREES.toLocaleString()}</TableCell>
                <TableCell className="text-right font-bold">{ADDITIONAL_EXTRA_TREES.toLocaleString()}</TableCell>
              </TableRow>
              <TableRow className="bg-primary/5 font-bold">
                <TableCell colSpan={3}>Total Geral</TableCell>
                <TableCell className="text-right">
                  {TREE_INVENTORY_DATA.reduce((acc, w) => acc + w.totalTrees, 0).toLocaleString()}
                </TableCell>
                <TableCell className="text-right">
                  {(
                    TREE_INVENTORY_DATA.reduce((acc, w) => acc + (w.extraTrees || 0), 0) + ADDITIONAL_EXTRA_TREES
                  ).toLocaleString()}
                </TableCell>
                <TableCell className="text-right">{GRAND_TOTAL_TREES.toLocaleString()}</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
