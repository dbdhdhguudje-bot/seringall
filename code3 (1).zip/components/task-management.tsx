"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { getTasks, addTask, updateTask, canTapSection } from "@/lib/storage"
import type { Task } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Plus, CheckCircle2, Clock, AlertCircle, Calendar } from 'lucide-react'
import { Alert, AlertDescription } from "@/components/ui/alert"

export function TaskManagement() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [tasks, setTasks] = useState<Task[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [taskSection, setTaskSection] = useState("")
  const [sectionAvailability, setSectionAvailability] = useState<Record<string, ReturnType<typeof canTapSection>>>({})

  useEffect(() => {
    loadTasks()
  }, [user])

  useEffect(() => {
    if (user) {
      const availability: Record<string, ReturnType<typeof canTapSection>> = {}
      const sections = getWorkerSections()
      sections.forEach(section => {
        availability[section] = canTapSection(section, user.id)
      })
      setSectionAvailability(availability)
    }
  }, [tasks, user])

  const loadTasks = () => {
    const allTasks = getTasks()
    if (user?.role === "worker") {
      setTasks(allTasks.filter((t) => t.workerId === user.id))
    } else {
      setTasks(allTasks)
    }
  }

  const handleCreateTask = () => {
    if (!user || !taskSection) return

    const availability = canTapSection(taskSection, user.id)
    if (!availability.canTap) {
      toast({
        title: "Seção não disponível",
        description: `A seção ${taskSection} só poderá ser sangrada novamente em ${availability.nextAvailableDate} (faltam ${availability.daysRemaining} dias)`,
        variant: "destructive",
      })
      return
    }

    const newTask: Task = {
      id: `task-${Date.now()}`,
      workerId: user.id,
      workerName: user.name,
      date: new Date().toISOString().split("T")[0],
      taskType: taskSection as any,
      status: "pending",
      productionKg: 0,
      createdAt: new Date().toISOString(),
    }

    addTask(newTask)
    loadTasks()
    setIsDialogOpen(false)
    toast({
      title: "Tarefa criada",
      description: `Tarefa ${taskSection} criada com sucesso`,
    })
  }

  const handleStartTask = (taskId: string) => {
    updateTask(taskId, { status: "in-progress" })
    loadTasks()
    toast({
      title: "Tarefa iniciada",
      description: "Boa sorte com a sangria!",
    })
  }

  const handleCompleteTask = (taskId: string) => {
    updateTask(taskId, {
      status: "completed",
      completedAt: new Date().toISOString(),
      lastTappingDate: new Date().toISOString().split("T")[0],
    })
    loadTasks()
    toast({
      title: "Tarefa concluída",
      description: "Tarefa finalizada com sucesso. Próxima sangria em 4 dias.",
    })
  }

  const getStatusBadge = (status: Task["status"]) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="gap-1">
            <Clock className="h-3 w-3" />
            Pendente
          </Badge>
        )
      case "in-progress":
        return (
          <Badge className="gap-1 bg-secondary text-secondary-foreground">
            <AlertCircle className="h-3 w-3" />
            Em Andamento
          </Badge>
        )
      case "completed":
        return (
          <Badge className="gap-1 bg-primary text-primary-foreground">
            <CheckCircle2 className="h-3 w-3" />
            Concluída
          </Badge>
        )
      case "inspected":
        return (
          <Badge className="gap-1 bg-accent text-accent-foreground">
            <CheckCircle2 className="h-3 w-3" />
            Inspecionada
          </Badge>
        )
    }
  }

  const filterTasksBySection = (section: string) => {
    return tasks.filter((t) => t.taskType === section)
  }

  const TaskCard = ({ task }: { task: Task }) => {
    const availability = user ? canTapSection(task.taskType, user.id) : { canTap: true }
    
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Tarefa {task.taskType}</CardTitle>
            {getStatusBadge(task.status)}
          </div>
          <CardDescription>
            {task.workerName} - {new Date(task.date).toLocaleDateString("pt-BR")}
          </CardDescription>
          {task.lastTappingDate && (
            <div className="text-xs text-muted-foreground mt-2 space-y-1">
              <div className="flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                <span>Última sangria: {new Date(task.lastTappingDate).toLocaleDateString("pt-BR")}</span>
              </div>
              {!availability.canTap && availability.nextAvailableDate && (
                <div className="text-amber-600 font-medium">
                  Próxima disponível: {new Date(availability.nextAvailableDate).toLocaleDateString("pt-BR")} ({availability.daysRemaining} dias)
                </div>
              )}
            </div>
          )}
        </CardHeader>
        <CardContent className="space-y-4">
          {user?.role === "worker" && task.status === "pending" && (
            <Button onClick={() => handleStartTask(task.id)} className="w-full">
              Iniciar Tarefa
            </Button>
          )}

          {user?.role === "worker" && task.status === "in-progress" && (
            <Button onClick={() => handleCompleteTask(task.id)} className="w-full">
              Concluir Tarefa
            </Button>
          )}
        </CardContent>
      </Card>
    )
  }

  const getWorkerSections = () => {
    if (!user) return []

    const sectionMap: Record<string, string[]> = {
      aquiles: ["A1", "A2", "A3", "A4"],
      messias: ["B1", "B2", "B3", "B4"],
      zuzueli: ["C1", "C2", "C3", "C4"],
      anderson: ["D1", "D2", "D3", "D4"],
      patrick: ["E1", "E2", "E3", "E4"],
      valdeci: ["F1", "F2", "F3", "F4"],
      fabio: ["G1", "G2", "G3", "G4"],
    }

    return sectionMap[user.name.toLowerCase()] || []
  }

  const workerSections = getWorkerSections()

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="min-w-0">
          <h2 className="text-2xl sm:text-3xl font-bold break-words">Sistema D4</h2>
          <p className="text-sm sm:text-base text-muted-foreground break-words">Gerenciamento de tarefas de sangria (intervalo de 4 dias)</p>
        </div>
        {user?.role === "worker" && (
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2 w-full sm:w-auto">
                <Plus className="h-4 w-4" />
                <span className="truncate">Nova Tarefa</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Criar Nova Tarefa</DialogTitle>
                <DialogDescription>Selecione a seção para criar uma tarefa (Sistema D4 - 4 dias entre sangrias)</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="task-section">Seção</Label>
                  <Select value={taskSection} onValueChange={setTaskSection}>
                    <SelectTrigger id="task-section">
                      <SelectValue placeholder="Selecione a seção" />
                    </SelectTrigger>
                    <SelectContent>
                      {workerSections.map((section) => {
                        const availability = sectionAvailability[section]
                        const isAvailable = availability?.canTap !== false
                        return (
                          <SelectItem 
                            key={section} 
                            value={section}
                            disabled={!isAvailable}
                          >
                            {section} {!isAvailable && `(disponível em ${availability.daysRemaining} dias)`}
                          </SelectItem>
                        )
                      })}
                    </SelectContent>
                  </Select>
                </div>
                {taskSection && sectionAvailability[taskSection] && !sectionAvailability[taskSection].canTap && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      Esta seção foi sangrada recentemente. Próxima sangria disponível em {sectionAvailability[taskSection].nextAvailableDate} (faltam {sectionAvailability[taskSection].daysRemaining} dias).
                    </AlertDescription>
                  </Alert>
                )}
                <div className="p-4 bg-muted rounded-lg space-y-2 text-sm">
                  <p className="font-semibold">Sistema D4 - Suas Seções:</p>
                  {workerSections.map((section) => {
                    const availability = sectionAvailability[section]
                    return (
                      <div key={section} className="flex items-center justify-between">
                        <span><strong>{section}:</strong> Gerenciamento de sangria</span>
                        {availability && !availability.canTap && (
                          <Badge variant="outline" className="text-xs">
                            {availability.daysRemaining}d restantes
                          </Badge>
                        )}
                        {availability && availability.canTap && (
                          <Badge variant="default" className="text-xs bg-green-600">
                            Disponível
                          </Badge>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
              <Button onClick={handleCreateTask} className="w-full" disabled={!taskSection}>
                Criar Tarefa
              </Button>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <Alert>
        <Calendar className="h-4 w-4" />
        <AlertDescription>
          <strong>Sistema D4:</strong> Cada seção só pode ser sangrada novamente após 4 dias da última sangria, garantindo a recuperação adequada das árvores.
        </AlertDescription>
      </Alert>

      {user?.role === "worker" ? (
        <Tabs defaultValue={workerSections[0]} className="w-full">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 gap-1">
            {workerSections.map((section) => (
              <TabsTrigger key={section} value={section} className="text-xs sm:text-sm">
                {section}
              </TabsTrigger>
            ))}
          </TabsList>
          {workerSections.map((section) => (
            <TabsContent key={section} value={section} className="space-y-4">
              {filterTasksBySection(section).length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    Nenhuma tarefa {section} encontrada
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {filterTasksBySection(section).map((task) => (
                    <TaskCard key={task.id} task={task} />
                  ))}
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      ) : (
        <Tabs defaultValue="A" className="w-full">
          <TabsList className="grid w-full grid-cols-3 sm:grid-cols-7 gap-1 h-auto">
            <TabsTrigger value="A" className="text-xs sm:text-sm py-2">Aquiles</TabsTrigger>
            <TabsTrigger value="B" className="text-xs sm:text-sm py-2">Messias</TabsTrigger>
            <TabsTrigger value="C" className="text-xs sm:text-sm py-2">Zuzueli</TabsTrigger>
            <TabsTrigger value="D" className="text-xs sm:text-sm py-2">Anderson</TabsTrigger>
            <TabsTrigger value="E" className="text-xs sm:text-sm py-2">Patrick</TabsTrigger>
            <TabsTrigger value="F" className="text-xs sm:text-sm py-2">Valdeci</TabsTrigger>
            <TabsTrigger value="G" className="text-xs sm:text-sm py-2">Fabio</TabsTrigger>
          </TabsList>
          {["A", "B", "C", "D", "E", "F", "G"].map((code) => (
            <TabsContent key={code} value={code} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {[1, 2, 3, 4].map((num) => {
                  const section = `${code}${num}`
                  const sectionTasks = filterTasksBySection(section)
                  return (
                    <div key={section}>
                      <h3 className="font-semibold mb-3">Seção {section}</h3>
                      {sectionTasks.length === 0 ? (
                        <Card>
                          <CardContent className="py-6 text-center text-sm text-muted-foreground">
                            Sem tarefas
                          </CardContent>
                        </Card>
                      ) : (
                        <div className="space-y-3">
                          {sectionTasks.map((task) => (
                            <TaskCard key={task.id} task={task} />
                          ))}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      )}
    </div>
  )
}
