"use client"

import { useEffect, useState } from "react"
import Image from "next/image"

interface SplashScreenProps {
  onComplete: () => void
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [fadeOut, setFadeOut] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setFadeOut(true)
      setTimeout(onComplete, 500)
    }, 2500)

    return () => clearTimeout(timer)
  }, [onComplete])

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-primary via-primary/90 to-secondary transition-opacity duration-500 ${
        fadeOut ? "opacity-0" : "opacity-100"
      }`}
    >
      <div className="flex flex-col items-center gap-8 animate-in fade-in zoom-in duration-700">
        <div className="relative">
          <div className="absolute inset-0 bg-accent/20 blur-3xl rounded-full animate-pulse" />
          <div className="relative bg-background/10 backdrop-blur-sm p-6 rounded-3xl border-4 border-accent/30 overflow-hidden">
            <Image
              src="/images/logo-fazenda-paraiso.png"
              alt="Logo Fazenda Paraíso"
              width={200}
              height={240}
              className="rounded-2xl animate-in spin-in duration-1000"
              priority
            />
          </div>
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold text-accent tracking-tight">Sistema de Gestão do Seringal</h1>
          <p className="text-lg text-accent/80 font-medium">Gestão de Sangria e Produção</p>
          <p className="text-sm text-accent/60">Borracha Natural</p>
        </div>

        {/* Loading indicator */}
        <div className="flex gap-2 mt-4">
          <div className="w-2 h-2 bg-accent rounded-full animate-bounce [animation-delay:-0.3s]" />
          <div className="w-2 h-2 bg-accent rounded-full animate-bounce [animation-delay:-0.15s]" />
          <div className="w-2 h-2 bg-accent rounded-full animate-bounce" />
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-secondary/30 to-transparent" />
    </div>
  )
}
