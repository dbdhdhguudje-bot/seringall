"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { User } from "./types"
import { initializeDemoData } from "./storage"

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    initializeDemoData()

    const storedUser = localStorage.getItem("currentUser")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    const usersData = localStorage.getItem("users")
    const users: User[] = usersData ? JSON.parse(usersData) : []

    // Normalizar entrada para lowercase
    const normalizedEmail = email.toLowerCase().trim()
    const normalizedPassword = password.toLowerCase().trim()

    // Verificar admin
    if (normalizedEmail === "admin" && normalizedPassword === "admin") {
      const adminUser: User = {
        id: "admin-1",
        name: "Administrador",
        email: "admin",
        role: "admin",
        createdAt: new Date().toISOString(),
      }
      setUser(adminUser)
      localStorage.setItem("currentUser", JSON.stringify(adminUser))
      return true
    }

    // Verificar fiscal
    if (normalizedEmail === "fiscal" && normalizedPassword === "fiscal") {
      const inspectorUser: User = {
        id: "inspector-1",
        name: "Fiscal Técnico",
        email: "fiscal",
        role: "inspector",
        createdAt: new Date().toISOString(),
      }
      setUser(inspectorUser)
      localStorage.setItem("currentUser", JSON.stringify(inspectorUser))
      return true
    }

    // Verificar seringueiros (workers)
    const foundUser = users.find(
      (u) => u.email.toLowerCase() === normalizedEmail || u.name.toLowerCase() === normalizedEmail,
    )

    if (foundUser && foundUser.role === "worker") {
      // Para seringueiros, a senha deve ser igual ao nome
      if (normalizedPassword === foundUser.name.toLowerCase()) {
        setUser(foundUser)
        localStorage.setItem("currentUser", JSON.stringify(foundUser))
        return true
      }
    }

    return false
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("currentUser")
  }

  return <AuthContext.Provider value={{ user, login, logout, isLoading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
