import type {
  Task,
  Inspection,
  ProductionRecord,
  User,
  MonthlyWeighing,
  StimulationRecord,
  PestControlRecord,
  PestControlAreaMap,
  PestInspectionSchedule,
  PestInspectionChecklist,
  PestControlTraining,
  WorkerPerformanceRating,
  AttendanceRecord, // Added import for AttendanceRecord
} from "./types"

function dispatchStorageUpdate() {
  window.dispatchEvent(new Event("localStorageUpdate"))
}

// Tasks
export function getTasks(): Task[] {
  const data = localStorage.getItem("tasks")
  return data ? JSON.parse(data) : []
}

export function saveTasks(tasks: Task[]): void {
  localStorage.setItem("tasks", JSON.stringify(tasks))
  dispatchStorageUpdate()
}

export function addTask(task: Task): void {
  const tasks = getTasks()
  tasks.push(task)
  saveTasks(tasks)
}

export function updateTask(taskId: string, updates: Partial<Task>): void {
  const tasks = getTasks()
  const index = tasks.findIndex((t) => t.id === taskId)
  if (index !== -1) {
    tasks[index] = { ...tasks[index], ...updates }
    if (updates.status === "completed" && !updates.lastTappingDate) {
      tasks[index].lastTappingDate = new Date().toISOString().split("T")[0]
    }
    saveTasks(tasks)
  }
}

// Inspections
export function getInspections(): Inspection[] {
  const data = localStorage.getItem("inspections")
  return data ? JSON.parse(data) : []
}

export function saveInspections(inspections: Inspection[]): void {
  localStorage.setItem("inspections", JSON.stringify(inspections))
  dispatchStorageUpdate()
}

export function addInspection(inspection: Inspection): void {
  const inspections = getInspections()
  inspections.push(inspection)
  saveInspections(inspections)
}

// Production Records
export function getProductionRecords(): ProductionRecord[] {
  const data = localStorage.getItem("productionRecords")
  return data ? JSON.parse(data) : []
}

export function saveProductionRecords(records: ProductionRecord[]): void {
  localStorage.setItem("productionRecords", JSON.stringify(records))
  dispatchStorageUpdate()
}

export function addProductionRecord(record: ProductionRecord): void {
  const records = getProductionRecords()
  records.push(record)
  saveProductionRecords(records)
}

// Monthly Weighings
export function getMonthlyWeighings(): MonthlyWeighing[] {
  const data = localStorage.getItem("monthlyWeighings")
  return data ? JSON.parse(data) : []
}

export function saveMonthlyWeighings(weighings: MonthlyWeighing[]): void {
  localStorage.setItem("monthlyWeighings", JSON.stringify(weighings))
  dispatchStorageUpdate()
}

export function addMonthlyWeighing(weighing: MonthlyWeighing): void {
  const weighings = getMonthlyWeighings()
  weighings.push(weighing)
  saveMonthlyWeighings(weighings)
}

export function updateMonthlyWeighing(weighingId: string, updates: Partial<MonthlyWeighing>): void {
  const weighings = getMonthlyWeighings()
  const index = weighings.findIndex((w) => w.id === weighingId)
  if (index !== -1) {
    weighings[index] = { ...weighings[index], ...updates }
    saveMonthlyWeighings(weighings)
  }
}

// Stimulation Records
export function getStimulationRecords(): StimulationRecord[] {
  const data = localStorage.getItem("stimulationRecords")
  return data ? JSON.parse(data) : []
}

export function saveStimulationRecords(records: StimulationRecord[]): void {
  localStorage.setItem("stimulationRecords", JSON.stringify(records))
  dispatchStorageUpdate()
}

export function addStimulationRecord(record: StimulationRecord): void {
  const records = getStimulationRecords()
  records.push(record)
  saveStimulationRecords(records)
}

export function deleteStimulationRecord(recordId: string): void {
  const records = getStimulationRecords()
  const filtered = records.filter((r) => r.id !== recordId)
  saveStimulationRecords(filtered)
}

// Pest Control Records
export function getPestControlRecords(): PestControlRecord[] {
  const data = localStorage.getItem("pestControlRecords")
  return data ? JSON.parse(data) : []
}

export function savePestControlRecords(records: PestControlRecord[]): void {
  localStorage.setItem("pestControlRecords", JSON.stringify(records))
  dispatchStorageUpdate()
}

export function addPestControlRecord(record: PestControlRecord): void {
  const records = getPestControlRecords()
  records.push(record)
  savePestControlRecords(records)
}

export function updatePestControlRecord(recordId: string, updates: Partial<PestControlRecord>): void {
  const records = getPestControlRecords()
  const index = records.findIndex((r) => r.id === recordId)
  if (index !== -1) {
    records[index] = { ...records[index], ...updates }
    savePestControlRecords(records)
  }
}

export function deletePestControlRecord(recordId: string): void {
  const records = getPestControlRecords()
  const filtered = records.filter((r) => r.id !== recordId)
  savePestControlRecords(filtered)
}

// Users
export function getUsers(): User[] {
  const data = localStorage.getItem("users")
  return data ? JSON.parse(data) : []
}

export function saveUsers(users: User[]): void {
  localStorage.setItem("users", JSON.stringify(users))
  dispatchStorageUpdate()
}

export function addUser(user: User): void {
  const users = getUsers()
  users.push(user)
  saveUsers(users)
}

export function initializeDemoData(): void {
  const users = getUsers()
  const tasks = getTasks()

  // Only initialize if no users exist yet
  if (users.length === 0) {
    const workers = [
      { id: "worker-1", name: "anderson" },
      { id: "worker-2", name: "valdeci" },
      { id: "worker-3", name: "aquiles" },
      { id: "worker-4", name: "patrick" },
      { id: "worker-5", name: "fabio" },
      { id: "worker-6", name: "messias" },
      { id: "worker-7", name: "zuzueli" },
    ]

    const newUsers: User[] = workers.map((worker) => ({
      ...worker,
      email: worker.name, // Email agora é igual ao nome
      role: "worker" as const,
      createdAt: new Date().toISOString(),
    }))

    saveUsers(newUsers)

    const newTasks: Task[] = []
    const workerSections: Record<string, string[]> = {
      "worker-3": ["A1", "A2", "A3", "A4"], // Aquiles
      "worker-6": ["B1", "B2", "B3", "B4"], // Messias
      "worker-7": ["C1", "C2", "C3", "C4"], // Zuzueli
      "worker-1": ["D1", "D2", "D3", "D4"], // Anderson
      "worker-4": ["E1", "E2", "E3", "E4"], // Patrick
      "worker-2": ["F1", "F2", "F3", "F4"], // Valdeci
      "worker-5": ["G1", "G2", "G3", "G4"], // Fabio
    }

    workers.forEach((worker) => {
      const sections = workerSections[worker.id] || []
      sections.forEach((section) => {
        newTasks.push({
          id: `${worker.id}-task-${section}`,
          workerId: worker.id,
          workerName: worker.name,
          date: new Date().toISOString().split("T")[0],
          taskType: section as any,
          status: "pending",
          productionKg: 0,
          createdAt: new Date().toISOString(),
        })
      })
    })

    saveTasks(newTasks)
  }
}

// Pest Control Area Maps
export function getPestControlAreaMaps(): PestControlAreaMap[] {
  const data = localStorage.getItem("pestControlAreaMaps")
  return data ? JSON.parse(data) : []
}

export function savePestControlAreaMaps(maps: PestControlAreaMap[]): void {
  localStorage.setItem("pestControlAreaMaps", JSON.stringify(maps))
  dispatchStorageUpdate()
}

export function addPestControlAreaMap(map: PestControlAreaMap): void {
  const maps = getPestControlAreaMaps()
  maps.push(map)
  savePestControlAreaMaps(maps)
}

export function updatePestControlAreaMap(mapId: string, updates: Partial<PestControlAreaMap>): void {
  const maps = getPestControlAreaMaps()
  const index = maps.findIndex((m) => m.id === mapId)
  if (index !== -1) {
    maps[index] = { ...maps[index], ...updates, updatedAt: new Date().toISOString() }
    savePestControlAreaMaps(maps)
  }
}

export function deletePestControlAreaMap(mapId: string): void {
  const maps = getPestControlAreaMaps()
  const filtered = maps.filter((m) => m.id !== mapId)
  savePestControlAreaMaps(filtered)
}

// Pest Inspection Schedules
export function getPestInspectionSchedules(): PestInspectionSchedule[] {
  const data = localStorage.getItem("pestInspectionSchedules")
  return data ? JSON.parse(data) : []
}

export function savePestInspectionSchedules(schedules: PestInspectionSchedule[]): void {
  localStorage.setItem("pestInspectionSchedules", JSON.stringify(schedules))
  dispatchStorageUpdate()
}

export function addPestInspectionSchedule(schedule: PestInspectionSchedule): void {
  const schedules = getPestInspectionSchedules()
  schedules.push(schedule)
  savePestInspectionSchedules(schedules)
}

export function updatePestInspectionSchedule(scheduleId: string, updates: Partial<PestInspectionSchedule>): void {
  const schedules = getPestInspectionSchedules()
  const index = schedules.findIndex((s) => s.id === scheduleId)
  if (index !== -1) {
    schedules[index] = { ...schedules[index], ...updates }
    savePestInspectionSchedules(schedules)
  }
}

export function deletePestInspectionSchedule(scheduleId: string): void {
  const schedules = getPestInspectionSchedules()
  const filtered = schedules.filter((s) => s.id !== scheduleId)
  savePestInspectionSchedules(filtered)
}

// Pest Inspection Checklists
export function getPestInspectionChecklists(): PestInspectionChecklist[] {
  const data = localStorage.getItem("pestInspectionChecklists")
  return data ? JSON.parse(data) : []
}

export function savePestInspectionChecklists(checklists: PestInspectionChecklist[]): void {
  localStorage.setItem("pestInspectionChecklists", JSON.stringify(checklists))
  dispatchStorageUpdate()
}

export function addPestInspectionChecklist(checklist: PestInspectionChecklist): void {
  const checklists = getPestInspectionChecklists()
  checklists.push(checklist)
  savePestInspectionChecklists(checklists)
}

export function updatePestInspectionChecklist(checklistId: string, updates: Partial<PestInspectionChecklist>): void {
  const checklists = getPestInspectionChecklists()
  const index = checklists.findIndex((c) => c.id === checklistId)
  if (index !== -1) {
    checklists[index] = { ...checklists[index], ...updates }
    savePestInspectionChecklists(checklists)
  }
}

export function deletePestInspectionChecklist(checklistId: string): void {
  const checklists = getPestInspectionChecklists()
  const filtered = checklists.filter((c) => c.id !== checklistId)
  savePestInspectionChecklists(filtered)
}

// Pest Control Training
export function getPestControlTrainings(): PestControlTraining[] {
  const data = localStorage.getItem("pestControlTrainings")
  return data ? JSON.parse(data) : []
}

export function savePestControlTrainings(trainings: PestControlTraining[]): void {
  localStorage.setItem("pestControlTrainings", JSON.stringify(trainings))
  dispatchStorageUpdate()
}

export function addPestControlTraining(training: PestControlTraining): void {
  const trainings = getPestControlTrainings()
  trainings.push(training)
  savePestControlTrainings(trainings)
}

export function deletePestControlTraining(trainingId: string): void {
  const trainings = getPestControlTrainings()
  const filtered = trainings.filter((t) => t.id !== trainingId)
  savePestControlTrainings(filtered)
}

// Worker Performance Rating
export function getPerformanceRatings(): WorkerPerformanceRating[] {
  const data = localStorage.getItem("performanceRatings")
  return data ? JSON.parse(data) : []
}

export function savePerformanceRatings(ratings: WorkerPerformanceRating[]): void {
  localStorage.setItem("performanceRatings", JSON.stringify(ratings))
  dispatchStorageUpdate()
}

export function savePerformanceRating(rating: WorkerPerformanceRating): void {
  const ratings = getPerformanceRatings()
  const existingIndex = ratings.findIndex(
    r => r.workerId === rating.workerId && r.month === rating.month
  )
  
  if (existingIndex !== -1) {
    // Update existing rating
    ratings[existingIndex] = rating
  } else {
    // Add new rating
    ratings.push(rating)
  }
  
  savePerformanceRatings(ratings)
}

export function deletePerformanceRating(ratingId: string): void {
  const ratings = getPerformanceRatings()
  const filtered = ratings.filter(r => r.id !== ratingId)
  savePerformanceRatings(filtered)
}

export function canTapSection(taskType: string, workerId: string): { canTap: boolean; nextAvailableDate?: string; daysRemaining?: number } {
  const tasks = getTasks()
  const sectionTasks = tasks.filter(t => t.taskType === taskType && t.workerId === workerId)
  
  if (sectionTasks.length === 0) {
    return { canTap: true }
  }
  
  // Find the most recent completed task for this section
  const completedTasks = sectionTasks
    .filter(t => t.status === "completed" && t.lastTappingDate)
    .sort((a, b) => new Date(b.lastTappingDate!).getTime() - new Date(a.lastTappingDate!).getTime())
  
  if (completedTasks.length === 0) {
    return { canTap: true }
  }
  
  const lastTappingDate = new Date(completedTasks[0].lastTappingDate!)
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  lastTappingDate.setHours(0, 0, 0, 0)
  
  const daysSinceLastTapping = Math.floor((today.getTime() - lastTappingDate.getTime()) / (1000 * 60 * 60 * 24))
  
  if (daysSinceLastTapping >= 4) {
    return { canTap: true }
  }
  
  const daysRemaining = 4 - daysSinceLastTapping
  const nextAvailableDate = new Date(lastTappingDate)
  nextAvailableDate.setDate(nextAvailableDate.getDate() + 4)
  
  return {
    canTap: false,
    nextAvailableDate: nextAvailableDate.toISOString().split("T")[0],
    daysRemaining
  }
}

// Attendance Records
export function getAttendanceRecords(): AttendanceRecord[] {
  const data = localStorage.getItem("attendanceRecords")
  return data ? JSON.parse(data) : []
}

export function saveAttendanceRecord(record: AttendanceRecord): void {
  const records = getAttendanceRecords()
  records.push(record)
  localStorage.setItem("attendanceRecords", JSON.stringify(records))
  dispatchStorageUpdate()
  window.dispatchEvent(new CustomEvent("storage-update", { detail: { key: "attendanceRecords" } }))
}

export function deleteAttendanceRecord(id: string): void {
  const records = getAttendanceRecords()
  const filtered = records.filter((r) => r.id !== id)
  localStorage.setItem("attendanceRecords", JSON.stringify(filtered))
  dispatchStorageUpdate()
  window.dispatchEvent(new CustomEvent("storage-update", { detail: { key: "attendanceRecords" } }))
}

export function getAttendanceByDateRange(startDate: string, endDate: string): AttendanceRecord[] {
  const records = getAttendanceRecords()
  return records.filter((r) => r.date >= startDate && r.date <= endDate)
}

export function getAttendanceByWorker(workerId: string): AttendanceRecord[] {
  const records = getAttendanceRecords()
  return records.filter((r) => r.workerId === workerId)
}
